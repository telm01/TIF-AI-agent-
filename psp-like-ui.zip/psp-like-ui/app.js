const games = [
  {
    name: "RACING X",
    icon: "🏎️",
    description: "High-speed arcade racing with local multiplayer support.",
    size: "1.2 GB",
    players: "1–4 PLAYERS",
    c1: "#1477a0", c2: "#40319b"
  },
  {
    name: "SPACE RAIDERS",
    icon: "🚀",
    description: "Defend the galaxy in a fast retro-inspired space shooter.",
    size: "850 MB",
    players: "1–2 PLAYERS",
    c1: "#9b3b7c", c2: "#192d75"
  },
  {
    name: "PIXEL QUEST",
    icon: "⚔️",
    description: "Explore a huge pixel world and defeat legendary bosses.",
    size: "620 MB",
    players: "1 PLAYER",
    c1: "#c06a2b", c2: "#4c267e"
  },
  {
    name: "STREET FIGHT",
    icon: "🥊",
    description: "Classic arcade fighting designed for a controller.",
    size: "430 MB",
    players: "1–2 PLAYERS",
    c1: "#a82e3f", c2: "#1e224d"
  },
  {
    name: "DRIFT CITY",
    icon: "🏁",
    description: "Master tight corners, drifting and time-attack challenges.",
    size: "980 MB",
    players: "1–4 PLAYERS",
    c1: "#137c65", c2: "#203b8c"
  },
  {
    name: "ZOMBIE NIGHT",
    icon: "🧟",
    description: "Survive waves of enemies in this couch co-op shooter.",
    size: "1.5 GB",
    players: "1–4 PLAYERS",
    c1: "#43592a", c2: "#24182e"
  }
];

let selected = 0;

const $ = id => document.getElementById(id);

function render() {
  const game = games[selected];

  $("heroIcon").textContent = game.icon;
  $("heroTitle").textContent = game.name;
  $("detailsTitle").textContent = game.name;
  $("detailsDescription").textContent = game.description;
  $("detailsSize").textContent = game.size;
  $("detailsPlayers").textContent = game.players;
  $("heroArt").style.background =
    `radial-gradient(circle at 70% 30%, rgba(255,255,255,.35), transparent 8%),
     linear-gradient(135deg, ${game.c1}, ${game.c2})`;

  $("carousel").innerHTML = games.map((g, i) => `
    <div class="card ${i === selected ? "selected" : ""}"
         style="--c1:${g.c1};--c2:${g.c2}"
         data-index="${i}">
      <div class="emoji">${g.icon}</div>
      <div class="name">${g.name}</div>
    </div>
  `).join("");

  $("dots").innerHTML = games.map((_, i) =>
    `<div class="dot ${i === selected ? "active" : ""}"></div>`
  ).join("");

  document.querySelectorAll(".card").forEach(card => {
    card.onclick = () => {
      selected = Number(card.dataset.index);
      render();
    };
  });
}

function move(direction) {
  selected = (selected + direction + games.length) % games.length;
  render();
}

$("prev").onclick = () => move(-1);
$("next").onclick = () => move(1);

$("launch").onclick = () => {
  alert(`Launching ${games[selected].name}...`);
};

document.addEventListener("keydown", e => {
  if (e.key === "ArrowLeft") move(-1);
  if (e.key === "ArrowRight") move(1);
  if (e.key === "Enter" || e.key === " ") $("launch").click();
  if (e.key === "Escape") selected = 0;
});

function updateClock() {
  $("time").textContent = new Date().toLocaleTimeString([], {
    hour: "2-digit",
    minute: "2-digit"
  });
}

render();
updateClock();
setInterval(updateClock, 1000);
